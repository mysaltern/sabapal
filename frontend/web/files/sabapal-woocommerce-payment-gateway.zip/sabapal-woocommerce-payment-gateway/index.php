<?php

/*
  Plugin Name: افزونه پرداخت امن صبا پال برای ووکامرس
  Version: 1
  Description:  افزونه درگاه پرداخت امن صبا پال برای فروشگاه ساز ووکامرس
  Plugin URI: https://sabapal.ir
  Author: Mohammad
  Author URI: http://www.sefroweb.com/

 */
include_once("class-wc-gateway-zarinpal.php");
